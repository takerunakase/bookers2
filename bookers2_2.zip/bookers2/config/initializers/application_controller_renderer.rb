# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = 'a786ca055785a1ddc52fe65391db0db57157dea7b40564ea8adaaa90e87270fb3fc9775142c0ad8396ce4ffca3f7544b935cf9561c0dd026a2520c5507d2ef8f'